# Social-Media-Sentiment-Analysis
Using Text Mining and Natural Language Processing Techniques pre- processed 50k tweets. Visualized the impact of hashtags on tweets sentiment using Seaborn. Applied machine learning models, calculated f1_scores, accordingly used the best model for sentiment prediction.
